#include<stdio.h>

int gu1()
{
	int sum = 0;
	
	for (int i = 2 ; i < 10; i++)
	{
		for (int j = 1; j < 10; j++)
			sum += i * j;
	}
	return sum;
}

void gu2(int n)
{
	for (int i = 1; i <= 9; i++)
	{
		printf("%dX%d=%2d ", n, i, n * i);
	}
		
}

void gu3(int n1, int n2)
{
	for (int i = 2; i <= 9; i++)
	{
		for (int j = n1; j <= n2; j++)
		{
			printf("%dX%d = %2d ", i, j, i * j);
		}
		printf("\n");
	}
}

int gu4(int n1,int n2)
{
	int sum = 0;

	for (int i = n1; i <=n2; i++)
	{
		for (int j = 1; j < 10; j++)
		{
		printf("%dX%d=%2d ", i, j, i * j);
			
			sum += i * j;
		}
		printf("\n");
	}
	return sum;
}

int main()
{
	//1
	printf("%d",gu1());
	printf("\n\n----------------------\n\n");
	//2
	gu2(5);
	printf("\n\n----------------------\n\n");
	//3
	gu3(1, 5);
	printf("\n\n----------------------\n\n");
	//4
	printf("sum = %d", gu4(2,6));

	return 0;
}