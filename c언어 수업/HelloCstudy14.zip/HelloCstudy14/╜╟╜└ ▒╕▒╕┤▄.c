#include<stdio.h>
void gugu()
{
	int dan1, dan2;
	printf("�� ��~�� ��:");
	scanf_s("%d %d", &dan1, &dan2);

	int n1, n2;
	printf("n1~n2���� ���մϴ�");
	scanf_s("%d %d", &n1, &n2);

	for (int i = dan1; i <= dan2; i++)
	{
		for (int j = n1; j <= n2; j++)
		{
			printf("%2d X %2d = %2d ", i, j, i * j);
		}
		printf("\n");
	}

}

int gu()
{
	for (int i = 2; i < 10; i++) 
	{
		for (int j = 1; j < 10; j++)
		{
			printf("%2d X %2d = %2d ", i, j, i * j);
		}
		printf("\n");
	}
}

int main()
{
	for (int i = 2; i < 10; i++)
	{
		for (int j = 1; j < 10; j++)
		{
			printf("%2d X %2d = %2d ", i, j, i * j);
		}
		printf("\n");
	}
	printf("\n\n-----------------------------\n\n");

	gu();
	printf("\n\n-----------------------------\n\n");
	
	gugu();

	return 0;
}

