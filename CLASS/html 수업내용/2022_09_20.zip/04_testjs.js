console.log('자바스크립트수업시작')
let input=prompt('나이 입력')
alert('내 나이는'+input+'세 입니다')