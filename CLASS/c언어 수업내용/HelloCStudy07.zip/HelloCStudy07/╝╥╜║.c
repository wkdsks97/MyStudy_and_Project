#include<stdio.h>
int main()
{
	char n[2];
	gets(n);
	printf("%s", n);

}