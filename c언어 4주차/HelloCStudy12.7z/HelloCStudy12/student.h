#pragma once
struct student
{
	int math;
	int eng;
	int kor;
}typedef Stu;

