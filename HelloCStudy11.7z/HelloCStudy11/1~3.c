#include<stdio.h>
//1��
void lar(int a,int b)
{
	if (a >= b)
		printf("%d", a);
	else
		printf("%d", b);
}
//2��
void lar2(int a, int b)
{
	if (a >= b)
		return a;
	else
		return b;
}
//3�� �Լ�
void swap(int* p, int* p1)
{
	int temp;
	temp = *p;
	*p = *p1;
	*p1 = temp;
}
int main()
{//1��
	lar(3, 5);
	printf("\n\n\n\n");

	lar2(2,4);
	printf("\n\n\n\n");
 
 //3��
	int a = 3;
	int b = 5;
	printf("a: %d, b: %d\n", a, b);
	swap(&a, &b);
	printf("a: %d, b: %d\n", a, b);
	return 0;
}