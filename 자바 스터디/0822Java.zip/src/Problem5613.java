import java.util.Scanner;

// 백준 5613번 문제 답안
public class Problem5613 {
	public static void main(String args[]) {
		// -> do-while문 및 switch문 사용
		Scanner s=new Scanner(System.in);
		int a=s.nextInt();//첫번째 숫자 입력받기
		// a=1
		do {
			// 변수 a를 중심으로 하여 연산이 진행됨
			char c=s.next().charAt(0);	// 연산자
			// c='+'
			if(c=='=') {break;}
			int b=s.nextInt();	// 두번째 숫자 입력받기
			// b=1
			switch(c) {
			case '+':	a+=b;	break;
				// a+=b -> 1+1=2 -> a에 저장됨
			case '-':	a-=b;	break;
			case '*':	a*=b;	break;
			case '/':	a/=b; 	break;
			case '%':	a%=b;	break;
			}
			//a=2
		}while(true);
		
		System.out.println(a);
	}
}
