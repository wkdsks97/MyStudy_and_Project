﻿namespace HelloMyCSharp05_03
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.ListText = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.gnerator_lotto_btn = new System.Windows.Forms.Button();
            this.lotto_result7 = new HelloMyCSharp05_03.CircularButton();
            this.lotto_result6 = new HelloMyCSharp05_03.CircularButton();
            this.lotto_result5 = new HelloMyCSharp05_03.CircularButton();
            this.lotto_result4 = new HelloMyCSharp05_03.CircularButton();
            this.lotto_result3 = new HelloMyCSharp05_03.CircularButton();
            this.lotto_result2 = new HelloMyCSharp05_03.CircularButton();
            this.lotto_result1 = new HelloMyCSharp05_03.CircularButton();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(54, 59);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(154, 59);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(248, 59);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(352, 59);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 3;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(54, 107);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 7;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(154, 107);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 6;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(248, 107);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 5;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(352, 107);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 4;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 8;
            this.label1.Text = "출력";
            // 
            // ListText
            // 
            this.ListText.AutoSize = true;
            this.ListText.Location = new System.Drawing.Point(57, 26);
            this.ListText.Name = "ListText";
            this.ListText.Size = new System.Drawing.Size(38, 12);
            this.ListText.TabIndex = 9;
            this.ListText.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 64);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 12);
            this.label3.TabIndex = 10;
            this.label3.Text = "추가";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "삭제";
            // 
            // gnerator_lotto_btn
            // 
            this.gnerator_lotto_btn.Location = new System.Drawing.Point(12, 161);
            this.gnerator_lotto_btn.Name = "gnerator_lotto_btn";
            this.gnerator_lotto_btn.Size = new System.Drawing.Size(415, 23);
            this.gnerator_lotto_btn.TabIndex = 12;
            this.gnerator_lotto_btn.Text = "로또 번호 생성";
            this.gnerator_lotto_btn.UseVisualStyleBackColor = true;
            this.gnerator_lotto_btn.Click += new System.EventHandler(this.generator_lotto_btn_Click);
            // 
            // lotto_result7
            // 
            this.lotto_result7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lotto_result7.FlatAppearance.BorderSize = 0;
            this.lotto_result7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lotto_result7.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotto_result7.Location = new System.Drawing.Point(889, 212);
            this.lotto_result7.Name = "lotto_result7";
            this.lotto_result7.Size = new System.Drawing.Size(123, 120);
            this.lotto_result7.TabIndex = 19;
            this.lotto_result7.Text = "45";
            this.lotto_result7.UseVisualStyleBackColor = false;
            // 
            // lotto_result6
            // 
            this.lotto_result6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lotto_result6.FlatAppearance.BorderSize = 0;
            this.lotto_result6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lotto_result6.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotto_result6.Location = new System.Drawing.Point(727, 212);
            this.lotto_result6.Name = "lotto_result6";
            this.lotto_result6.Size = new System.Drawing.Size(123, 120);
            this.lotto_result6.TabIndex = 18;
            this.lotto_result6.Text = "45";
            this.lotto_result6.UseVisualStyleBackColor = false;
            // 
            // lotto_result5
            // 
            this.lotto_result5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lotto_result5.FlatAppearance.BorderSize = 0;
            this.lotto_result5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lotto_result5.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotto_result5.Location = new System.Drawing.Point(585, 212);
            this.lotto_result5.Name = "lotto_result5";
            this.lotto_result5.Size = new System.Drawing.Size(123, 120);
            this.lotto_result5.TabIndex = 17;
            this.lotto_result5.Text = "45";
            this.lotto_result5.UseVisualStyleBackColor = false;
            // 
            // lotto_result4
            // 
            this.lotto_result4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lotto_result4.FlatAppearance.BorderSize = 0;
            this.lotto_result4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lotto_result4.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotto_result4.Location = new System.Drawing.Point(435, 212);
            this.lotto_result4.Name = "lotto_result4";
            this.lotto_result4.Size = new System.Drawing.Size(123, 120);
            this.lotto_result4.TabIndex = 16;
            this.lotto_result4.Text = "45";
            this.lotto_result4.UseVisualStyleBackColor = false;
            // 
            // lotto_result3
            // 
            this.lotto_result3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lotto_result3.FlatAppearance.BorderSize = 0;
            this.lotto_result3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lotto_result3.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotto_result3.Location = new System.Drawing.Point(295, 212);
            this.lotto_result3.Name = "lotto_result3";
            this.lotto_result3.Size = new System.Drawing.Size(123, 120);
            this.lotto_result3.TabIndex = 15;
            this.lotto_result3.Text = "45";
            this.lotto_result3.UseVisualStyleBackColor = false;
            // 
            // lotto_result2
            // 
            this.lotto_result2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lotto_result2.FlatAppearance.BorderSize = 0;
            this.lotto_result2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lotto_result2.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotto_result2.Location = new System.Drawing.Point(154, 212);
            this.lotto_result2.Name = "lotto_result2";
            this.lotto_result2.Size = new System.Drawing.Size(123, 120);
            this.lotto_result2.TabIndex = 14;
            this.lotto_result2.Text = "45";
            this.lotto_result2.UseVisualStyleBackColor = false;
            // 
            // lotto_result1
            // 
            this.lotto_result1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.lotto_result1.FlatAppearance.BorderSize = 0;
            this.lotto_result1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lotto_result1.Font = new System.Drawing.Font("Gill Sans Ultra Bold", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lotto_result1.Location = new System.Drawing.Point(15, 212);
            this.lotto_result1.Name = "lotto_result1";
            this.lotto_result1.Size = new System.Drawing.Size(123, 120);
            this.lotto_result1.TabIndex = 13;
            this.lotto_result1.Text = "45";
            this.lotto_result1.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1088, 390);
            this.Controls.Add(this.lotto_result7);
            this.Controls.Add(this.lotto_result6);
            this.Controls.Add(this.lotto_result5);
            this.Controls.Add(this.lotto_result4);
            this.Controls.Add(this.lotto_result3);
            this.Controls.Add(this.lotto_result2);
            this.Controls.Add(this.lotto_result1);
            this.Controls.Add(this.gnerator_lotto_btn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.ListText);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label ListText;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button gnerator_lotto_btn;
        private CircularButton lotto_result1;
        private CircularButton lotto_result2;
        private CircularButton lotto_result3;
        private CircularButton lotto_result4;
        private CircularButton lotto_result5;
        private CircularButton lotto_result6;
        private CircularButton lotto_result7;
    }
}

